<nav>
    <ul>
        <li><a href="lista_tareas.php">Lista de Tareas</a></li>
        <li><a href="agregar_tarea.php">Agregar Tarea</a></li>
        <li><a href="todas_las_tareas.php">Todas las Tareas</a></li>
    </ul>
</nav>
