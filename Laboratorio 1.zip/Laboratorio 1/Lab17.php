<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Laboratorio 1.7</title>
</head>
<body>
    <?php
    $x =24;
    $pi = 3.1416;
    $animal = "conejo";
    $saludo ="Hola caracola";
    echo $x, "<br>", $pi, "<br>", $animal, "<br>", $saludo;
  
?>
</body>
</html>