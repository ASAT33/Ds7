<?php
// Verificar las credenciales (esto es solo un ejemplo)
$usuario_valido = "usuario";
$contrasena_valida = "contrasena";

if ($_POST["username"] == $usuario_valido && $_POST["password"] == $contrasena_valida) {
    // Si las credenciales son válidas, redirigir a la página principal
    header("Location: principal.html");
    exit();
} else {
    echo "Credenciales incorrectas. Por favor, intenta nuevamente.";
}
?>
